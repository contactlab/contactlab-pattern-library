class Starter{

	beforeRegister(){
		this.is = "starter";
	}

}

Polymer(Starter);